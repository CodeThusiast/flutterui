import 'package:flutter/material.dart';
import "package:learn_flutter/shapes.dart";

void main() => runApp(LineApp());

class LineApp extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home:AuthUI(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class AuthUI extends StatefulWidget{
  @override
  _AuthUIState createState() {
    return _AuthUIState();
  }
}

class _AuthUIState extends State<AuthUI>{
  @override
  Widget build(BuildContext context) {

    final Widget formContainer= Container( // Email-Password Form 
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.7),
        borderRadius: BorderRadius.all(Radius.circular(40))
      ),
      padding: EdgeInsets.only(right:20,left:20),
      child: Form(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextFormField(
              style: TextStyle(
                fontFamily: 'Comfortaa',
                fontSize: 22,
                color: Colors.green[900]
              ),
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.account_circle),
                hintText:"Email",
                border: OutlineInputBorder(
                  //borderRadius: BorderRadius.all(Radius.circular(30)),
                  borderSide:BorderSide.none,
                ),
                filled:false,
              ),
            ),
            Divider(color: Colors.indigo[900],height:5),
            TextFormField(
              style: TextStyle(
                fontFamily: 'Comfortaa',
                fontSize: 22,
                color: Colors.green[900]
              ),
              decoration: InputDecoration(
                prefixIcon: Icon(Icons.vpn_key),
                hintText: "Password",
                border: OutlineInputBorder(
                  borderSide: BorderSide.none
                ),
                filled: false,
              ),
            ),
          ],
        ),
      ),
    );

    var size=MediaQuery.of(context).size;
    return Scaffold(
      body:ListView(
        padding: EdgeInsets.all(0),
        children: <Widget>[
          Container(
            height: size.height,
            child:CustomPaint(
              painter: MyPaint(),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    SizedBox(height: 80),
                    Center(
                      child:FlutterLogo(
                        size: 100,
                      ),
                    ),

                    SizedBox(height:20),
                    Center(
                      child: Text(
                        "Sign In",
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: 'Comfortaa',
                          fontSize:22,
                        ),
                      ),
                    ),
                    SizedBox(height: 40),
                    Container(
                      width: 83,
                      height: 50,
                      decoration: BoxDecoration(
                        borderRadius:BorderRadius.only(topLeft:Radius.circular(25),bottomLeft:Radius.circular(25)),
                        gradient: LinearGradient(
                          colors: [
                            Colors.green,
                            Colors.teal
                          ]
                        )
                      ),
                      child: MaterialButton(
                        onPressed: (){},
                        child: Text(
                          "Sign Up",
                          style: TextStyle(
                            fontFamily: 'Comfortaa',
                            color: Colors.white
                          ),
                        ),
                      ),
                    ),  
                    SizedBox(height: 20),
                    Stack(
                      children:<Widget>[
                        Container(
                          margin: EdgeInsets.only(left:40,right: 40),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.all(Radius.circular(40)),
                            boxShadow: <BoxShadow>[
                              BoxShadow(
                                color: Colors.black.withOpacity(.3),
                                blurRadius:10,
                                spreadRadius:6
                              )
                            ]
                          ),
                          child: formContainer,
                        ),
                        Positioned(
                          right:15,
                          top:35,
                          child: Container(
                            width: 50,
                            height: 50,
                            decoration: BoxDecoration(
                              shape:BoxShape.circle,
                              boxShadow:<BoxShadow>[
                                BoxShadow(
                                  color: Colors.black.withOpacity(.3),
                                  blurRadius: 5,
                                  spreadRadius: 5
                                ),
                              ],
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: <Color>[
                                  Colors.green,
                                  Colors.teal
                                ]
                              )
                            ),
                            child: IconButton(
                              onPressed: (){},
                              iconSize:35,
                              color:Colors.indigo,
                              icon: Icon(Icons.navigate_next,color: Colors.white),
                            )
                          ),
                        ),
                        Positioned(
                          left:15,
                          top:35,
                          child: Container(
                            width:50,
                            height:50,
                            padding: EdgeInsets.all(15),
                            decoration: BoxDecoration(
                              shape:BoxShape.circle,
                              boxShadow:<BoxShadow>[
                                BoxShadow(
                                  color: Colors.black.withOpacity(.3),
                                  blurRadius: 5,
                                  spreadRadius: 5
                                ),
                              ],
                              gradient: LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: <Color>[
                                  Colors.pink,
                                  Colors.red[400]
                                ]
                              ),
                            ),
                            child:Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage("assets/images/ask.png")
                                )
                              ),
                            )
                          )
                        )
                      ]
                    ),

                    SizedBox(height: 60)
                ],
                ),
              )
            )
          )
        ]
      ),
      resizeToAvoidBottomPadding: false,
    );
  }
}