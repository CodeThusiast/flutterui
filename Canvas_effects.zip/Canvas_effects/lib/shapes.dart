import "package:flutter/material.dart";

class MyPaint extends CustomPainter{
  @override
  void paint(Canvas canvas, Size size) {
    var width=size.width;
    var height=size.height;
    Paint paint =Paint()
    ..color=Colors.white
    ..strokeWidth=2;

    // top gradient

    var gradient1=LinearGradient(
      begin:Alignment.bottomLeft,
      end: Alignment.topRight,
      colors: <Color>[
        Colors.green[700],
        Colors.teal[300]
      ],
      tileMode: TileMode.mirror
    );

    // gradient of the path at center
    var centerGradient=LinearGradient(
      begin: Alignment.topRight,
      end: Alignment.bottomLeft,
      colors: <Color>[
        Colors.green[900],
        Colors.teal[400],
      ],
    );

    // bottom gradient
    var gradient2=LinearGradient(
      begin: Alignment.topLeft,
      end:Alignment.bottomRight,
      colors: <Color>[
        Colors.teal[700],
        Colors.green[300]
      ]
    );
    
    //Rectangle of the top gradient
    Rect top=Rect.fromPoints(Offset(0,0),Offset(width,160));
    //Rectangle of the bottom gradient
    Rect bottom=Rect.fromPoints(Offset(0,height-160),Offset(width,height));

    canvas.drawRect(top, paint..shader=gradient1.createShader(top));
    canvas.drawRect(bottom, paint..shader=gradient2.createShader(bottom));
    // Top Path
    Path path=Path()
    ..moveTo(0,160)
    ..quadraticBezierTo(0,80,width/4,60)
    ..quadraticBezierTo(width,30,width,0)
    ..lineTo(width,height-160)
    ..cubicTo(width,height,0,height,0,height-160)
    ..lineTo(0,160);
    canvas.drawPath(path,paint..shader=centerGradient.createShader(top));

    // Add black shadow mask
    canvas.drawShadow(path,Colors.black.withOpacity(.9), 15, true);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}